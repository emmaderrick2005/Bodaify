# Bodaify 🏍️

**AI-powered fleet intelligence for Kampala boda boda operations**

A full-stack web application providing incline-aware routing, jam prediction, road quality mapping, fuel optimization, predictive maintenance, DEM elevation integration, and fuel auditing.

---

## Features

| Module | Description |
|---|---|
| ⛰ Incline-Aware Routing | Dijkstra routing with elevation penalty and 4 route modes |
| ◉ Jam Predictor | Congestion model by area, hour & day with weekly heatmap |
| ⟁ Road Quality Map | Accelerometer-based RQI scoring and Kampala simulation |
| ◬ Fuel Optimizer | Physics-based fuel-to-weight ratio engine |
| ⚙ Predictive Maintenance | Component wear analysis and failure risk scoring |
| △ DEM Elevation | SRTM-style terrain profiling with SVG visualisation |
| ▦ Fuel Audit Dashboard | Fleet-wide fuel consumption with anomaly detection |


---

## Quick Start

### Option 1 — Docker (Recommended)

```bash
docker-compose up --build
```

Then open: http://localhost:8000

### Option 2 — Local Python

```bash
cd backend
pip install -r requirements.txt
python main.py
```

Then open: http://localhost:8000

### Option 3 — Windows PowerShell

```powershell
cd backend
pip install -r requirements.txt
python main.py
```

### Option 4 — Linux / macOS shell script

```bash
chmod +x start.sh
./start.sh
```

---

## API Documentation

Interactive docs available at: http://localhost:8000/api/docs

### Key Endpoints

```
POST /api/routing/calculate       Incline-aware route calculation
POST /api/jam/predict             Congestion prediction
GET  /api/jam/heatmap             Full city heatmap
GET  /api/jam/weekly/{area}       7-day forecast
POST /api/road-quality/analyze    Single accelerometer reading
GET  /api/road-quality/simulate   Kampala road quality map
POST /api/fuel/optimize           Fuel-to-weight optimization
POST /api/maintenance/analyze     Predictive maintenance diagnostics
GET  /api/maintenance/fleet-status Fleet health overview
GET  /api/dem/profile             Elevation profile between coordinates
GET  /api/dem/kampala-terrain     Full terrain grid
GET  /api/fuel-audit/dashboard    Fleet fuel audit
POST /api/fuel-audit/submit       Submit fuel entry
```

---

## Project Structure

```
BodaifyApp/
├── backend/
│   ├── main.py                   FastAPI application entry point
│   ├── requirements.txt
│   ├── models/
│   │   └── schemas.py            Pydantic models and enums
│   ├── routers/
│   │   ├── routing.py            Incline-aware Dijkstra routing
│   │   ├── jam_predictor.py      Congestion prediction engine
│   │   ├── road_quality.py       Accelerometer RQI analysis
│   │   ├── fuel.py               Fuel-to-weight optimizer
│   │   ├── maintenance.py        Predictive maintenance API
│   │   ├── fuel_audit.py         Fuel audit dashboard
│   │   └── dem.py                DEM elevation integration
│   └── data/
│       └── kampala_graph.py      34-node Kampala road network
├── frontend/
│   ├── index.html                Single-page application
│   ├── css/style.css             Industrial dark theme
│   └── js/app.js                 Full frontend logic
├── Dockerfile
├── docker-compose.yml
├── start.sh
├── start.bat
└── README.md
```

---

## Tech Stack

- **Backend**: FastAPI · Pydantic v2 · Uvicorn
- **Algorithm**: Dijkstra with elevation-weighted edges
- **Terrain**: Simulated SRTM/Copernicus DEM (swap `simulate_elevation()` for real API)
- **Frontend**: Vanilla JS · SVG charts · CSS custom properties
- **Fonts**: Syne · JetBrains Mono
- **Deployment**: Docker · docker-compose

---

## Configuration

To connect a real DEM data source, replace `simulate_elevation()` in `backend/routers/dem.py`:

```python
# Production: query Copernicus DEM or SRTM via OpenTopography API
def simulate_elevation(lat: float, lon: float) -> float:
    response = requests.get(
        f"https://api.opentopodata.org/v1/srtm30m?locations={lat},{lon}"
    )
    return response.json()["results"][0]["elevation"]
```

---

## Kampala Road Network

The routing engine models **34 nodes** and **43 edges** across Greater Kampala including:
Kampala CBD, Nakasero, Kololo, Makerere, Mulago, Wandegeya, Kawempe, Kisaasi, Ntinda, Nakawa, Luzira, Muyenga, Ggaba, Makindye, Kabalagala, Mengo, Rubaga, Namirembe, Katwe, Nateete, Entebbe Road, Munyonyo, Bugolobi, Kireka, Namugongo, Gayaza Road, Jinja Road, Northern Bypass, and more.

---

## Fuel Price Reference (2026)

Default fuel price: **UGX 5,200 / litre**  
Update in `backend/routers/routing.py` → `FUEL_PRICE_UGX_PER_LITER`

---

## License

MIT — Built for Kampala, 2026. Bodaify.
